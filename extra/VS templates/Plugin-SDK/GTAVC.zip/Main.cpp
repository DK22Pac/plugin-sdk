#include "plugin_vc.h"

using namespace plugin;

class MyPlugin {
public:
    MyPlugin() {

    }
} myPlugin;