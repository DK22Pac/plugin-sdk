#include "plugin.h"

using namespace plugin;

class MyPlugin {
public:
    MyPlugin() {
        // Initialise your plugin here
        
    }
} myPlugin;