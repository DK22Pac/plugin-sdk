#include "plugin_III.h"

using namespace plugin;

class MyPlugin {
public:
    MyPlugin() {
        // Initialise your plugin here
        
    }
} myPlugin;